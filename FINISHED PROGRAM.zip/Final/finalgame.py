'''
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
#####
Hanzala Siddiqui
Penalty Shootout Game
Version 1 .0
This is my Final Penalty Shootout program.
The player uses the spacebar to cycle through controlling the height, width, and speed of the shot to score and then the height, width and speed of the goalkeeper to save. The player must score and save more than the opponent in order to win the game.
'''
import pygame
import sys
import random
import time
import datetime

def runGame():
    count = 0
    entity_color = (0, 0, 0)
    entity_color2 = (255, 255, 255)

    def draw_text(surf, text, font_size, x, y):  # for showing higscores
        font = pygame.font.Font(None, font_size)
        text_surface = font.render(text, True, entity_color2)
        text_rect = text_surface.get_rect()
        text_rect.midtop = (x, y)
        surf.blit(text_surface, text_rect)

    class TimedValue:

        def __init__(self):
            self._started_at = datetime.datetime.utcnow()

        def __call__(self):

            time_passed = datetime.datetime.utcnow() - self._started_at
            if time_passed.total_seconds() > 3:
                return False
            else:
                return True

    class Background(pygame.sprite.Sprite):  # Creates space background
        def __init__(self, image_file, location):
            pygame.sprite.Sprite.__init__(self)  # call Sprite initializer
            self.image = pygame.image.load(image_file)
            self.rect = self.image.get_rect()
            self.rect.left, self.rect.top = location

    class Entity(pygame.sprite.Sprite):
        """Inherited by any object in the game."""

        def __init__(self, x, y, width, height):
            pygame.sprite.Sprite.__init__(self)

            self.x = x
            self.y = y
            self.width = width
            self.height = height
            # This makes a rectangle around the entity, used for anything
            # from collision to moving around.
            self.rect = pygame.Rect(self.x, self.y, self.width, self.height)

    class PlayerI(Entity):
        """
        Player controlled or AI controlled, main interaction with
        the game
        """

        def __init__(self, x, y, width, height):
            super(PlayerI, self).__init__(x, y, width, height)

            self.image = userImg  # makes spaceship accessible to player class

    class GoalieI(Entity):
        def __init__(self, x, y, width, height):
            super(GoalieI, self).__init__(x, y, width, height)

            self.image = goalk  # makes spaceship accessible to player class

    class Player(PlayerI):
        """The player controlled person"""

        def __init__(self, x, y, width, height):
            super(Player, self).__init__(x, y, width, height)

            # How many pixels the Player Destroyer should move on a given frame.
            self.y_change = 575
            # How many pixels the Destroyer should move each frame a key is pressed.
            self.y_dist = 60

        def Clicked(self, type):
            """Responds to a key-down event and moves accordingly"""

            self.rect.y = 515
        def PlayerReset(self):
            self.rect.x=410
            self.rect.y=575

    class Goalie(GoalieI):
        def __init__(self, x, y, width, height):
            super(Goalie, self).__init__(x, y, width, height)

        def Clicked(self, type, sh, sw, sp):
            """Responds to a key-down event and moves accordingly"""
            psg = []
            if (sh < 200):
                saveh = 10
                ph = 0
            elif (sh >= 200 and h < 250):
                saveh = 100
                ph = 1
            else:
                saveh = 170
                ph = 2
            if (sw < 800):
                savew = 230
                pw = 0
            elif (sw >= 800 and sw < 850):
                savew = 330
                pw = 1
            elif (sw >= 850 and sw < 900):
                savew = 430
                pw = 2
            elif (sw >= 900 and sw < 950):
                savew = 530
                pw = 3
            else:
                savew = 630
                pw = 0

            self.rect.x = savew
            self.rect.y = saveh
            psg.append(ph)
            psg.append(pw)
            return psg

        def saveRandom(self):
            rsg = []
            rh = random.randrange(1, 3)
            rw = random.randrange(1, 4)
            if (rh == 1):
                rsaveh = 100
            elif (rh == 2):
                rsaveh = 170
            if (rw == 1):
                rsavew = 330
            elif (rw == 2):
                rsavew = 430
            elif (rw == 3):
                rsavew = 530
            rsg.append(rh)
            rsg.append(rw)
            self.rect.x = rsavew
            self.rect.y = rsaveh
            return rsg

        def goalieReset(self):
            self.rect.x = 430
            self.rect.y = 170

    class BallI(Entity):

        def __init__(self, x, y, width, height):
            super(BallI, self).__init__(x, y, width, height)

            self.image = matchball

    class Ball(BallI):
        def __init__(self, x, y, width, height):
            super(Ball, self).__init__(x, y, width, height)

        def Clicked(self, type, h, w, p):
            """Responds to a key-down event and moves accordingly"""
            psb = []
            if (h < 200):
                shoth = 50
                pshoth = 0
            elif (h >= 200 and h < 250):
                shoth = 150
                pshoth = 1
            else:
                shoth = 250
                pshoth = 2
            if (w < 800):
                shotw = 300
                pshotw = 0
            elif (w >= 800 and w < 850):
                shotw = 400
                pshotw = 1
            elif (w >= 850 and w < 900):
                shotw = 500
                pshotw = 2
            elif (w >= 900 and w < 950):
                shotw = 600
                pshotw = 3
            else:
                shotw = 700
                pshotw = 0
            soccerball.rect.x = shotw
            soccerball.rect.y = shoth
            psb.append(pshoth)
            psb.append(pshotw)
            return psb

        def shotRandom(self):
            rsb = []
            rh = random.randrange(1, 3)
            rw = random.randrange(1, 4)
            if (rh == 1):
                rshoth = 150
            elif (rh == 2):
                rshoth = 250
            if (rw == 1):
                rshotw = 400
            elif (rw == 2):
                rshotw = 500
            elif (rw == 3):
                rshotw = 600
            soccerball.rect.x = rshotw
            soccerball.rect.y = rshoth
            rsb.append(rh)
            rsb.append(rw)
            return rsb

        def ballReset(self):
            soccerball.rect.x = 500
            soccerball.rect.y = 500

    class Bar(Entity):
        """
        Player controlled or AI controlled, main interaction with
        the game
        """

        def __init__(self, x, y, width, height):
            super(Bar, self).__init__(x, y, width, height)

            self.image = pygame.Surface([self.width, self.height])
            self.image.fill(entity_color)

    class ShotBar(Bar):
        def __init__(self, x, y, width, height):
            super(ShotBar, self).__init__(x, y, width, height)

        def cchange(self):
            self.image.fill((255, 0, 0))

        def cchange2(self):
            self.image.fill((255, 255, 0))

        def cchange3(self):
            self.image.fill((0, 255, 0))

        def cchange4(self):
            self.image.fill(entity_color2)

    class BarCalculator(Entity):
        def __init__(self, x, y, width, height):
            super(BarCalculator, self).__init__(x, y, width, height)

            self.image = pygame.Surface([self.width, self.height])
            self.image.fill(entity_color)

    class HeightCalcBall(BarCalculator):
        def __init__(self):
            pygame.sprite.Sprite.__init__(self)
            self.image = pygame.Surface((25, 7.5))
            self.image.fill(entity_color)
            self.rect = self.image.get_rect()
            self.rect.x = 850
            self.rect.y = 150
            self.speedy = 5

        def update(self):
            self.rect.y += self.speedy
            if (self.rect.y >= 350):
                self.speedy *= -1
            elif (self.rect.y <= 150):
                self.speedy *= -1

    class WidthCalcBall(BarCalculator):
        def __init__(self):
            pygame.sprite.Sprite.__init__(self)
            self.image = pygame.Surface((7.5, 25))
            self.image.fill(entity_color)
            self.rect = self.image.get_rect()
            self.rect.x = 750
            self.rect.y = 450
            self.speedx = 5

        def update(self):
            self.rect.x += self.speedx
            if (self.rect.x >= 1000):
                self.speedx *= -1
            elif (self.rect.x <= 750):
                self.speedx *= -1

    class PowerCalcBall(BarCalculator):
        def __init__(self):
            pygame.sprite.Sprite.__init__(self)
            self.image = pygame.Surface((7.5, 25))
            self.image.fill(entity_color)
            self.rect = self.image.get_rect()
            self.rect.x = 750
            self.rect.y = 600
            self.speedx = 5

        def update(self):
            self.rect.x += self.speedx
            if (self.rect.x >= 1000):
                self.speedx *= -1
            elif (self.rect.x <= 750):
                self.speedx *= -1

    pygame.init()


    def gameisover(n,ps,es):
        while True:


            listAsteroid = []  # makes asteroid list empty so no asteroids appear
            listLaser = []  # makes laser list empty so no lasers appear
            screen.fill((0,0,0))
            pygame.display.flip()
            if n==1:
                draw_text(screen, "YOU WIN!", 70, 500, 250)
            elif n==2:
                draw_text(screen, "YOU LOSE!", 70, 500, 250)
            draw_text(screen, "Final Score " , 65, 500, 350)
            draw_text(screen, str(ps)+'-'+str(es) , 65, 500, 450)

            soundObj.stop()
            soundObj2.stop()
            pygame.display.flip()
            running = False
            while (running == False):
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()

                time.sleep(5)
                runGame()





    # screen info
    window_width = 1050
    window_height = 800
    screen = pygame.display.set_mode((window_width, window_height))
    pygame.display.set_caption("World Cup Penalty Shootout")
    clock = pygame.time.Clock()
    screen.fill([255, 255, 255])

    # images
    BackGround = Background('grassbg.jpg', [0, 0])
    goal = pygame.image.load('goal.png')

    userImg = pygame.image.load('player.png')
    userImg = pygame.transform.scale(userImg, (200, 200))

    goalk = pygame.image.load('goalkeeper.png')
    goalk = pygame.transform.scale(goalk, (200, 200))
    matchball = pygame.image.load('ball.png')

    user = Player(410, 575, 200, 200)
    goalkeeper = Goalie(430, 175, 200, 200)
    soccerball = Ball(500, 500, 50, 54)
    all_sprites_list = pygame.sprite.Group()
    all_sprites_list.add(user)
    all_sprites_list.add(goalkeeper)
    all_sprites_list.add(soccerball)
    ps = 0
    es = 0
    act = 'Shoot'
    r = 0
    x=False

    shotheightbar = ShotBar(850, 200, 25, 150)
    shotheightbar.cchange4()
    shotheightbar2 = ShotBar(850, 150, 25, 50)
    shotheightbar2.cchange()

    shotwidthbar = ShotBar(750, 450, 250, 25)
    shotwidthbar2 = ShotBar(800, 450, 150, 25)
    shotwidthbar.cchange()
    shotwidthbar2.cchange4()

    shotpowerbar = ShotBar(750, 600, 250, 25)
    shotpowerbar.cchange()
    shotpowerbar2 = ShotBar(800, 600, 150, 25)
    shotpowerbar2.cchange2()
    shotpowerbar3 = ShotBar(850, 600, 50, 25)
    shotpowerbar3.cchange3()

    all_sprites_list.add(shotwidthbar)
    all_sprites_list.add(shotwidthbar2)
    all_sprites_list.add(shotheightbar)
    all_sprites_list.add(shotheightbar2)
    all_sprites_list.add(shotpowerbar)
    all_sprites_list.add(shotpowerbar2)
    all_sprites_list.add(shotpowerbar3)

    heightcalcbar = HeightCalcBall()
    heightcalcbar.update()

    widthcalcbar = WidthCalcBall()
    widthcalcbar.update()

    powercalcbar = PowerCalcBall()
    powercalcbar.update()
    soundObj = pygame.mixer.Sound('cheer.wav')
    soundObj2 = pygame.mixer.Sound('miss.wav')
    soundObj3 = pygame.mixer.Sound('win.wav')
    soundObj4 = pygame.mixer.Sound('boo.wav')
    running = False
    while (running == False):
        screen.blit(BackGround.image, BackGround.rect)
        myfont = pygame.font.SysFont(None, 40)
        nlabel = myfont.render("Penalty Shootout Game", 1, (0, 0, 0))
        nLabel2 = myfont.render("Controls: Use the spacebar to control your height width and power.", 1, (0, 0, 0))
        nLabel3 = myfont.render("Tip: Avoid the red!", 1, (255, 0, 0))
        nLabel4 = myfont.render("Left click the screen to get started!", 1, (0, 0, 0))
        nLabel5 = myfont.render("Sudden Death!", 1, (255, 255, 255))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:  # Left mouse button.
                    running = True
        screen.blit(nlabel, (375, 50))
        screen.blit(nLabel2, (100, 100))
        screen.blit(nLabel3, (400, 150))
        screen.blit(nLabel4, (300, 350))
        pygame.display.flip()
    while True:
        if x:
            screen.blit(nLabel5, (450, 400))
            value=TimedValue()

            pygame.display.flip()
            time.sleep(3)
            x=value.__call__()



        if x==False:
            screen.blit(BackGround.image, BackGround.rect)
            screen.blit(goal, (330, 0))
            draw_text(screen, "Height", 40, 790, 150)
            draw_text(screen, "Width", 40, 790, 400)
            draw_text(screen, "Power", 40, 790, 550)

            draw_text(screen, str(ps), 75, 65, 50)
            draw_text(screen, 'Your Score', 45, 170, 60)
            draw_text(screen, str(es), 75, 65, 100)
            draw_text(screen, 'Oppenent Score', 45, 210, 110)
            draw_text(screen, 'Action: ', 45, 100, 500)
            draw_text(screen, act, 45, 200, 500)




        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:

                if r < 5:

                    if event.key == pygame.K_SPACE:
                        if count == 0:
                            act = 'Shoot'
                            all_sprites_list.add(heightcalcbar)
                            count += 1

                        elif count == 1:
                            h = heightcalcbar.rect.y
                            all_sprites_list.remove(heightcalcbar)
                            all_sprites_list.add(widthcalcbar)
                            count += 1

                        elif count == 2:
                            w = widthcalcbar.rect.x
                            all_sprites_list.remove(widthcalcbar)
                            all_sprites_list.add(powercalcbar)
                            count += 1

                        elif count == 3:
                            p = powercalcbar.rect.x
                            all_sprites_list.remove(powercalcbar)
                            user.Clicked(type)
                            psb = soccerball.Clicked(type, h, w, p)
                            rsg = goalkeeper.saveRandom()

                            if psb[0] == 0 or psb[1] == 0:
                                soundObj2.play()
                                pass

                            elif psb[1] == rsg[1] and psb[0] == rsg[0]:
                                soundObj2.play()
                                pass

                            elif psb[1] != rsg[1]:
                                ps += 1
                                soundObj.play()
                            elif psb[1] == rsg[1] and psb[0] != rsg[0]:
                                if psb[0] + 1 == rsg[0] or psb[0] - 1 == rsg[0]:
                                    if (p >= 850 and p < 900):
                                        ps += 1
                                        soundObj.play()
                                    else:
                                        soundObj2.play()
                                        pass




                                else:
                                    ps += 1
                                    soundObj.play()
                            else:
                                ps += 1
                                soundObj.play()

                            count += 1

                        elif count == 4:
                            soundObj.stop()
                            soundObj2.stop()
                            soccerball.ballReset()
                            goalkeeper.goalieReset()
                            user.PlayerReset()
                            act = 'Save'
                            all_sprites_list.add(heightcalcbar)
                            count += 1

                        elif count == 5:
                            sh = shotheightbar.rect.y
                            all_sprites_list.remove(heightcalcbar)
                            all_sprites_list.add(widthcalcbar)
                            count += 1

                        elif count == 6:
                            sw = widthcalcbar.rect.x
                            all_sprites_list.remove(widthcalcbar)
                            all_sprites_list.add(powercalcbar)
                            count += 1

                        elif count == 7:
                            sp = powercalcbar.rect.x
                            all_sprites_list.remove(powercalcbar)
                            user.Clicked(type)
                            psg = goalkeeper.Clicked(type, sh, sw, sp)
                            rsb = soccerball.shotRandom()

                            if psg[0] == 0 or psg[1] == 0:
                                es += 1
                                soundObj2.play()
                            elif psg[1] == rsb[1] and psg[0] == rsb[0]:
                                soundObj.play()
                                pass

                            elif psg[1] != rsb[1]:
                                es += 1
                                soundObj2.play()
                            elif psg[1] == rsb[1] and psg[0] != rsb[0]:

                                if psg[0] + 1 == rsb[0] or psg[0] - 1 == rsb[0]:

                                    if (p >= 850 and p < 900):
                                        soundObj.play()
                                        pass

                                    else:

                                        es += 1
                                        soundObj2.play()



                                else:

                                    es += 1
                                    soundObj2.play()
                            else:
                                es += 1
                                soundObj2.play()
                            count += 1

                        elif count == 8:
                            soundObj.stop()
                            soundObj2.stop()
                            user.PlayerReset()
                            goalkeeper.goalieReset()
                            soccerball.ballReset()
                            count = 0
                            act = ''
                            r += 1

                elif r == 5:
                    act = ''
                    if ps > es:

                        soundObj3.play()

                        gameisover(1,ps,es)
                    elif es > ps:

                        soundObj4.play()

                        gameisover(2,ps,es)
                    else:

                        x=True
                        pygame.display.update()
                        r -= 1
                        count = 0

        for ent in all_sprites_list:
            ent.update()
        all_sprites_list.update()

        all_sprites_list.draw(screen)

        pygame.display.update()
        pygame.display.flip()

        clock.tick(60)


runGame()